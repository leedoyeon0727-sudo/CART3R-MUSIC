# CART3R MUSIC — Android Studio 프로젝트

갤럭시 S22에서 사용할 수 있는 Android 음악 플레이어의 시작 프로젝트입니다.

## 현재 포함된 기능
- Jetpack Compose 기반 Spotify풍 다크 UI
- Android 시스템 파일 선택기로 기기 내 오디오 파일 열기
- AndroidX Media3 ExoPlayer로 선택한 파일 재생/일시정지/탐색
- 재생 진행 바와 재생 시간 표시
- Spotify 공식 앱 실행 버튼

## 중요한 Spotify 제한
이 프로젝트는 Spotify Premium을 무료로 해제하거나 Spotify 음원을 추출/재생하지 않습니다.
Spotify 버튼은 설치된 공식 Spotify 앱을 실행합니다. Spotify Android App Remote SDK를 연결하면
사용자 동의 후 공식 앱의 재생을 원격 제어하고 현재 재생 메타데이터를 받을 수 있지만,
Spotify 앱이 기기에 설치되어 있어야 합니다. Spotify 콘텐츠의 스트리밍은 Spotify 정책과
계정 자격 요건을 따라야 하며, Spotify API는 무손실 오디오 파일을 앱에 제공하는 API가 아닙니다.

## 빌드 방법
1. Android Studio를 설치하고 실행합니다.
2. `CART3R_MUSIC_Android` 폴더를 Open으로 엽니다.
3. Gradle JDK를 17로 설정합니다.
4. Gradle Sync가 끝날 때까지 기다립니다.
5. 갤럭시 S22에서 개발자 옵션과 USB 디버깅을 활성화하고 USB로 연결합니다.
6. Run을 누릅니다.
7. APK 파일이 필요하면 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.

APK 출력 위치:
`app/build/outputs/apk/debug/app-debug.apk`

## 지원 음원 형식
Media3/Android 플랫폼 디코더와 기기 코덱 지원 범위에 따라 달라집니다.
FLAC/WAV 등은 기기에서 선택해 재생을 시도할 수 있습니다. 모든 코덱/샘플레이트/비트뎁스가
항상 하드웨어 경로로 출력된다는 뜻은 아닙니다.

## Spotify 공식 연동을 추가하려면
- Spotify Developer Dashboard에서 앱을 등록합니다.
- 공식 Android SDK의 App Remote 및 Authorization 안내를 따릅니다.
- 패키지명과 Redirect URI를 등록하고 사용자에게 필요한 권한을 요청합니다.
- 앱의 연결/인증 코드를 별도 모듈로 추가해야 합니다.
- Client Secret을 Android 앱에 하드코딩하지 마세요. 공개 클라이언트 앱에는 PKCE 등
  적절한 사용자 인증 흐름을 사용하고 Spotify의 최신 개발자 정책을 확인하세요.

## 프로젝트 상태
이 파일은 로컬 오디오 재생이 가능한 소스 프로젝트입니다. 이 환경에서는 Android SDK/Gradle로
실제 APK를 컴파일하거나 기기에서 테스트하지 않았습니다. 따라서 APK가 이미 빌드되었다고
표시하지 않습니다.
